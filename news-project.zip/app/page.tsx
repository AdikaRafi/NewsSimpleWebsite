import FeaturedNews from "./components/main_news";
import { getThreeFeaturedNews } from "./api/news_data";

export default async function Home() {
  const newsData = await getThreeFeaturedNews();
  return (
    <main>
      <FeaturedNews news={newsData}/>
    </main>
  );
}
