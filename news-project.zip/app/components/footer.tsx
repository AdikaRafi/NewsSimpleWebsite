import React from 'react';
import Link from 'next/link';
import { HeartIcon } from 'lucide-react';
import { FaGithub } from 'react-icons/fa';
import { FaLinkedin } from 'react-icons/fa';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="w-full border-t border-gray-200 bg-white py-6 dark:bg-gray-950 dark:border-gray-800 transition-colors duration-300">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Layout Grid 3 Kolom untuk Desktop, Flex Column untuk Mobile */}
        <div className="flex flex-col items-center gap-4 md:grid md:grid-cols-3">
          
          {/* BAGIAN KIRI: Copyright & Identitas */}
          {/* md:items-start menjaga teks rata kiri di desktop */}
          <div className="flex flex-col items-center md:items-start order-2 md:order-1">
            <span className="text-sm font-semibold text-gray-900 dark:text-gray-100">
              The Daily News Project
            </span>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 text-center md:text-left">
              &copy; {currentYear} Simple Project NextJS.
            </p>
          </div>

          {/* BAGIAN TENGAH: Tech Stack Badge */}
          {/* md:justify-center memastikan ini DEAD CENTER */}
          <div className="flex items-center justify-center gap-1 text-xs text-gray-500 dark:text-gray-500 order-1 md:order-2 w-full">
              <span>Dibuat dengan</span>
              <HeartIcon size={12} className="text-red-500 fill-red-500 mx-0.5" />
              <span>pakai</span>
              <span className="font-medium text-gray-700 dark:text-gray-300">Next.js</span>
              <span>&</span>
              <span className="font-medium text-gray-700 dark:text-gray-300">Tailwind</span>
          </div>

          {/* BAGIAN KANAN: Socials & Repo Link */}
          {/* md:justify-end melempar ikon ke paling kanan */}
          <div className="flex items-center justify-center md:justify-end gap-4 order-3 md:order-3">
            <Link 
              href="https://github.com/AdikaRafi" 
              target="_blank"
              className="text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
              aria-label="GitHub Repository"
            >
              <FaGithub size={20} />
            </Link>
            <Link 
              href="https://linkedin.com/in/adika-brahmana-rafi-sejati" 
              target="_blank"
              className="text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
              aria-label="LinkedIn"
            >
              <FaLinkedin size={20} />
            </Link>
          </div>

        </div>
      </div>
    </footer>
  );
};

export default Footer;